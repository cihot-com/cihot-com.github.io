// window，是点击插件按钮时打开的插件页面的window
window.onload = ()=>{
	let c = document.createElement('hr')
	window.document.body.prepend(c)
	c = c.style
	c.border = 'none'
	c.height = '2px'
	c.margin = 0
	c.padding = 0
	c.backgroundColor = 'blue'
	c.boxShadow = '2px 2px #000'
}


// p = chrome.runtime.connect()
// window.addEventListener('message',(e)=>{
// 	console.log('是否自己', e.source === window)

// 	console.log(e.data.type, e.data)
// 	p.postMessage(e.data.text)
// })


console.log(`插件运行成功(v1.0)`)

